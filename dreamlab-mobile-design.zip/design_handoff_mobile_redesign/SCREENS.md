# Screens

Ten screens, designed at 390×844 (iPhone 14/15 logical). All are single-column, full-bleed to the viewport, gutter 24px unless stated. See `DreamLab Mobile Site.dc.html` for the live versions and `COMPONENTS.md` for component values.

Section order below is top-to-bottom in the scroll.

---

## 01 · Home — `/`

**Purpose.** State what DreamLab does and get the visitor to one of two actions: book a visit, or browse programmes.

**Layout**

1. **Nav bar**, root state.
2. **Hero**, padding `44px 24px 36px`.
   - Eyebrow: `RESIDENTIAL AI TRAINING · CUMBRIA`, cyan mono 11px `.16em`, 20px below.
   - H1 32/1.15/600/-.02em: *"Bring your team to the Lake District. Leave with a working prototype."*
   - Body 17/1.6 `rgba(250,250,250,.62)`: *"One to three days in a solar-powered deep-tech lab, shaped around your challenge."* 28px below.
   - Primary button `Schedule a lab visit` → `/contact`.
   - Text link `See the 38 programme ideas →` → `/programmes`, 48px tall, 8px gap.
3. **Photo**, full-bleed 200px — `/images/venue/aerial.webp`.
4. **Stat quad** — £8M+ / 30 yrs / 44+ / 6.3kW.
5. **What we train**, padding `44px 24px`.
   - H2 22px, sub 15px: *"Eight tracks, 38 course ideas — every one shaped around your team."*
   - Eight compact list rows → `/programmes#<id>`.
6. **Three ways in**, padding `44px 24px`.
   - H2 22px, then three detail rows: title 17/600 left, duration chip right in cyan mono (`1–3 DAYS`, `1–3 DAYS`, `12–36 MTHS`), one-line outcome at 14px.
7. **The lab**, padding `0 24px 44px`.
   - H2 22px, then five read-only chips: 10G network · 8× RTX GPU cluster · LED volume stage · 24-speaker spatial sound · Full-board residential.
   - Closing line 15px with `Meet the team →`.
8. **Footer**, `#0B0B0E`, padding `28px 24px 130px`. Wrapped link row at 14px `rgba(250,250,250,.6)`: Community · Impact stories · Privacy · LinkedIn · Bluesky. Copyright 12px `rgba(250,250,250,.35)`.
9. **Sticky action bar** — `Schedule a lab visit` + 50px `✉` icon button → `/contact`.

**Behaviour.** No hero animation below `md`; `HyperdimensionalHeroBackground` and `VoronoiGoldenHero` should not mount. No scroll-chevron, no auto-rotating carousel.

**Cut from the current page.** The `min-h-screen` animated hero; the facility feature 2×2 box grid (folded into chips); the eight glass cards (now rows); the three co-create cards (now rows); the team preview section (the link in "The lab" covers it); the dual enterprise/SME CTA blocks (the sticky bar and `/co-create` cover them); the standalone email signup block (folded into Enquire). Nine sections → six.

---

## 02 · Menu — overlay

**Purpose.** Reach any destination in one tap.

**Layout.** Own nav bar with `×` close. `THE LAB` group: Programmes · Co-create · Research · Software ecosystem · Self-guided workshops. `THE PEOPLE` group: Team · Impact stories · Community forum. Footer block: primary `Schedule a lab visit`, then Contact · LinkedIn · Bluesky · Privacy.

**Behaviour.** Opens from the nav bar hamburger. Flat — no submenus. Trap focus, close on Escape / route change / backdrop, lock body scroll. `aria-expanded` on the trigger.

**State.** `isOpen: boolean`, local.

---

## 03 · Programmes — `/programmes`

**Purpose.** Show the full training offer and let the visitor either pick a track or skip straight to describing their problem.

**Layout**

1. Nav bar, pushed state, title `Programmes`.
2. Intro `32px 24px 24px`: H1 30px *"38 residential ideas to spark your own."*; body 16/1.65 — the agentics/spatial/prototyping/distributed line plus the "every course is unique" caveat, stated **once** on this screen.
3. Eight detail rows: title 18/600 with count right-aligned in mono, blurb 14px below. → track detail.
4. **Not sure which?** block above the fold end: H2 18px, 15px body, outline button `Describe your challenge` → `/contact`.

**Behaviour.** Rows navigate; no filtering at this size — eight items don't need it.

---

## 04 · Track detail — `/programmes#<track-id>`

**Purpose.** Show what a track actually contains, then enquire.

**Layout**

1. Nav bar, pushed, title = track name.
2. Header `32px 24px 28px`: cyan mono eyebrow `TRACK 02 · 6 COURSE IDEAS`; H1 30px (the track's own promise); body 16px — *"These are starting points, not a catalogue. Every course is shaped around your team and the problem you bring."*
3. Six detail rows — title 17/600, description 14px, meta `2 DAYS · RESIDENTIAL` in mono.
4. **Who teaches it**: H2 18px, 15px body ending in `Meet the team →`.
5. 110px spacer, then sticky bar: `Enquire about this track` → `/contact` with the track pre-filled.

**Note.** The six course ideas shown in the mock are illustrative and were written for it. Wire real course data from the programmes source; keep the shape (title / one-line description / duration + format meta).

---

## 05 · Workshops — `/workshops`

**Purpose.** Let a self-guided learner resume, or start.

**Layout**

1. Nav bar, pushed, title `Workshops`.
2. Header: eyebrow `FREE · NO ACCOUNT NEEDED`; H1 30px *"The VS Code learning pathway."*; body 16px — *"Fifteen modules, roughly a morning or an afternoon each."*
3. Progress summary: label row + 4px bar.
4. Fifteen rows from `src/data/workshop-list.json`: module number in mono (22px column), title 16px, meta 13px (`Morning · intermediate`), right-hand `DONE` / `RESUME` state.

**Behaviour.** Progress from `useWorkshopProgress`; `RESUME` appears on the first incomplete module only. Tapping any row opens the module.

**Naming.** Source names (`01 - Morning Vscode Setup`) are machine-cased. Display as `01` + `VS Code setup` + `Morning · beginner`. Either fix the generator (`scripts/generate-workshop-list.mjs`) or add a display-name map — do not sentence-case at render and hope.

---

## 06 · Workshop module — `/workshops/:id/:slug`

**Purpose.** Read and work through one module on a phone.

**Layout**

1. Nav bar, pushed: back · `04 · AI agents` · step counter `2/6` in mono. Directly beneath, a 2px progress bar full-bleed.
2. Body `32px 24px 24px`: eyebrow `MORNING · INTERMEDIATE · 3 HRS`; H1 28px; prose at **17/1.7** `rgba(250,250,250,.75)`.
3. Prerequisite callout: 2px cyan left rule, 16px inset, 15px body with an inline link. Not a boxed card.
4. Code block: `#08080A`, `1px solid rgba(255,255,255,.08)`, radius 10px, padding 16px, 13px/1.7 mono `#C9D1D9`, `overflow-x: auto`.
5. Inline code in prose: 14px mono `#FAFAFA`, no background pill.
6. 120px spacer, then sticky bar: 50px outline `‹` + primary `Mark done · next step`.

**Behaviour.** Marking done advances the step and updates both progress bars. Prose measure is the full gutter width — no max-width games at 390px.

---

## 07 · Co-create — `/co-create`

**Purpose.** Explain the three commercial routes properly, for someone who has decided to talk.

**Layout**

1. Nav bar, pushed, title `Co-create`.
2. Header: H1 30px *"Embed in our lab."*; body 16px.
3. Three blocks, hairline-separated, padding `24px 0`:
   - Title 20/600 left, duration in cyan mono right.
   - Description 15/1.65 `rgba(250,250,250,.62)`.
   - Outcome line in mono `.45` — `OUTCOME · WORKING PROTOTYPE AT TRL 4–6`.
   - Text link — `Scope an engagement →` / `Enquire about a sprint →` / `Check eligibility →`.
4. Primary button `Design your engagement` at the end, padding `32px 24px 44px`.

**Note.** This is the one screen where each route gets its full description — on Home the same three appear as one-line rows. That's Rule 5 working: detail lives in one place.

---

## 08 · Team — `/team`

**Purpose.** Browse specialists and select the ones you want on your project.

**Layout**

1. Nav bar, pushed, title `Team`.
2. Header: H1 30px *"44+ specialists, one lab."*; body 16px — Emmy nominees, PhD researchers, BAFTA-recognised talent; *"Tap anyone you'd want on your project."*
3. Two-column grid of selectable cards, `gap: 12px`, gutter 20px.
4. 110px spacer.
5. Sticky bar: `N specialists selected` at 14px `rgba(250,250,250,.6)` left, `Enquire` primary right (auto width, 20px padding).

**Behaviour.** Unchanged from `src/pages/Team.tsx` — `selectedMembers: string[]`, toggle on tap, enquire navigates to `/contact?team=<names>`. Enquire is disabled at zero selections. Members still load from `/data/team/manifest.json` + per-member markdown.

**Note.** The shipped page's instruction ("Click on a team member to select them") sits above a selection counter and a disabled button; on mobile the counter belongs in the bar where the action is, not in the header.

---

## 09 · Impact stories — `/testimonials`

**Purpose.** Evidence, in the customer's own words.

**Layout**

1. Nav bar, pushed, title `Impact stories`.
2. H1 30px *"What people left with."*
3. Quote blocks, hairline-separated, padding `26px 0`:
   - Quote 19/1.55 `#FAFAFA`, `text-wrap: pretty`, in curly quotes.
   - Attribution 14px `rgba(250,250,250,.6)` — `Name · Role`.
   - Context 11px mono `.4` — `1-DAY WORKSHOP · ON-SITE, LONDON`.

**Content.** From `src/data/testimonials.json` verbatim. Order featured first. The quote is the largest text in the block — no avatar, no card, no star rating.

---

## 10 · Enquire — `/contact`

**Purpose.** One place to start a conversation. Absorbs the old email signup.

**Layout**

1. Nav bar, pushed, title `Enquire`.
2. Header: H1 28px *"Tell us what you're working on."*; body 16px — *"We'll come back with dates and a shaped outline — usually within two working days."*
3. Fields, 20px apart: Your name · Email · What's the challenge? (optional, 4-row textarea).
4. Engagement chips: Enterprise / SME / KTP, single-select, Enterprise default.
5. Consent row — 22px checkbox, 14px copy, inline privacy link.
6. Primary `Send enquiry`, full width, 52px.
7. Reassurance under the button, 13px `rgba(250,250,250,.42)`: *"Sent end-to-end encrypted. Only we can read it, and we don't store it anywhere else."*

**Behaviour.** Submission is unchanged from `src/components/EmailSignupForm.tsx`: ephemeral identity, NIP-17 gift-wrapped DM to the admin pubkey, success only on relay OK-true, graceful degrade if `VITE_RELAY_URL` / `VITE_ADMIN_PUBKEY` are unset. Validation messages via the existing `sonner` toasts. Pre-fill from `?team=` (Team screen) and from a track referrer.

**State.** `name`, `email`, `challenge`, `engagementType`, `hasConsent`, `isSubmitting`.

**Note.** The encryption line is new copy. It is currently buried in a code comment and an ADR — it's a genuine differentiator on a contact form and belongs in front of the user.
