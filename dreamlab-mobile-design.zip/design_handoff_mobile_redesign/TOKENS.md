# Design tokens

Every value below is either inherited verbatim from the shipped codebase or a stated, reasoned change to it. Hex values are exact — use them as written.

---

## 1. Where the current values come from

| Token | Shipped source | Value |
|---|---|---|
| `--background` | `src/index.css` `:root` | `hsl(240 10% 3.9%)` = `#09090B` |
| `--foreground` | `src/index.css` | `hsl(0 0% 98%)` = `#FAFAFA` |
| `--muted-foreground` | `src/index.css` | `hsl(240 5% 82%)` ≈ `#CFCFD5` |
| `--primary` | `src/index.css` | `hsl(217 91% 60%)` = `#3B82F6` (blue-500) |
| `--border` | `src/index.css` | `hsl(240 3.7% 15.9%)` ≈ `#26262B` |
| `--radius` | `src/index.css` | `0.5rem` |
| `--dl-card-bg` | `src/styles/design-tokens.css` | `rgba(31,41,55,.5)` |
| `--dl-card-border` | `src/styles/design-tokens.css` | `rgba(55,65,81,.5)` |
| `--dl-surface-dark` | `src/styles/design-tokens.css` | `#111827` |
| Hero anthracite | `HyperdimensionalHeroBackground.tsx` docblock | `#0E0E11` |
| Hero bronze / gold / bright gold | same | `#CD7F32` · `#D4A574` · `#FFD700` |
| Track accents | `src/styles/design-tokens.css` | green `34,197,94` · purple `168,85,247` · pink `236,72,153` · sky `56,189,248` · amber `245,158,11` · blue `96,165,250` |
| CTA fill | `Index.tsx`, `Header.tsx` | `bg-gradient-to-r from-cyan-600 to-cyan-500` = `#0891B2 → #06B6D4` |
| Touch floor | `src/index.css` base layer | `min-height: 44px; min-width: 44px` |

---

## 2. Mobile surfaces

The mobile base moves from `#09090B` to the hero's `#0E0E11` — a warmer anthracite that is already the brand's own hero background, and reads less like a void behind body text.

| Name | Value | Use |
|---|---|---|
| Base | `#0E0E11` | page background |
| Sunken | `#0B0B0E` | footer, sticky action bar, code blocks |
| Raised | `#17171C` | selectable cards, media wells |
| Hairline | `rgba(255,255,255,.08)` | list rules between items |
| Hairline strong | `rgba(255,255,255,.12)` | chip and outline-button borders |
| Field | `rgba(255,255,255,.03)` | input fill |
| Nav scrim | `rgba(14,14,17,.92)` + `backdrop-filter: blur(14px)` | sticky nav bar |

**Replaces:** `--dl-card-bg` `rgba(31,41,55,.5)` + `--dl-card-border` `rgba(55,65,81,.5)` + `backdrop-filter: blur(8px)` (the `.glass-card` treatment). Glass cards stay on desktop; on mobile they become hairline-separated rows.

## 3. Text

| Name | Value | Use |
|---|---|---|
| Foreground | `#FAFAFA` | headings, list titles, quote text |
| Body | `rgba(250,250,250,.62)` | paragraphs |
| Muted | `rgba(250,250,250,.45)` | meta, mono labels, counts |
| Faint | `rgba(250,250,250,.35)` | chevrons, copyright, done-state |

Never below `.35`. The shipped build drops to `text-muted-foreground/60` and `.4` alpha in several places (outcome-card counts, footer) — those come up to `.45` minimum.

## 4. Action

The shipped CTA gradient is flattened to solid cyan-500 with a dark ink label: same colour family, higher contrast, no banding on a 50px button, one fewer paint layer.

| Name | Value | Use |
|---|---|---|
| Action | `#06B6D4` | primary button fill |
| Action ink | `#04202A` | label on cyan fill |
| Action bright | `#22D3EE` | links, eyebrows, dots, active tab |
| Action tint | `rgba(34,211,238,.12)` | selected chip / card fill |
| Action border | `#22D3EE` | selected chip / card border (1px), selection ring (2px) |

Contrast: `#04202A` on `#06B6D4` ≈ 8.9:1. `#22D3EE` on `#0E0E11` ≈ 11.4:1. `rgba(250,250,250,.62)` on `#0E0E11` ≈ 8.3:1. All pass AA at body size; the first two pass AAA.

## 5. Inherited palettes — data only

Kept verbatim, allowed on charts, track keys, and the desktop hero. **Not** for mobile card borders or icon tiles.

`#D4A574` gold · `#CD7F32` bronze · `#FFD700` bright gold · `#F59E0B` amber · `#38BDF8` sky · `#60A5FA` blue · `#A855F7` purple · `#EC4899` pink · `#22C55E` green · `#2DD4BF` teal · `#818CF8` indigo · `#FB923C` orange

## 6. Type

Stack unchanged: Tailwind default sans (`ui-sans-serif, system-ui, -apple-system, "Segoe UI", …`). Meta labels use `ui-monospace, Menlo, monospace`.

| Role | Size / line-height / weight / tracking | Notes |
|---|---|---|
| Home H1 | 32 / 1.15 / 600 / -.02em | was 24 (`text-2xl`) |
| Page H1 | 30 / 1.18 / 600 / -.02em | |
| Section H2 | 22 / 1.3 / 600 / -.01em | was 24 — smaller, because H1 got bigger |
| Card / route H2 | 20 / 1.3 / 600 | |
| Pull quote | 19 / 1.55 / 400 | |
| List title | 17 / 1.65 / 600 | |
| Reading body | 17 / 1.7 / 400 | workshop module prose |
| Intro body | 16 / 1.65 / 400 | at Body colour |
| Supporting | 14 / 1.55 / 400 | at Muted-ish `.55` |
| Meta / eyebrow | 11 mono / 1 / 500 / .16em, uppercase | cyan when it labels the current thing, muted otherwise |
| Input text | 16 | **hard floor — below this iOS zooms on focus** |

All headings: `letter-spacing: -.02em` and `text-wrap: pretty`. Body never below 15px except mono meta at 11px and the 13px caption under stat figures.

**Why the change:** the shipped mobile hero is `text-2xl` (24px) headline over `text-lg` (18px) subhead — a 1.33 ratio that reads as two subheads with no clear first voice. Going 32/17 restores a 1.9 ratio.

## 7. Spacing

Scale: `4 · 8 · 12 · 16 · 20 · 24 · 32 · 44 · 64`

| Role | Value | Was |
|---|---|---|
| Screen gutter | 24px | 20px (`px-5`) |
| Section rhythm | 44px | 64px (`py-16`) — desktop spacing on a phone |
| List row padding | 14–18px vertical | card `p-5`/`p-6` |
| Stack gap inside a block | 8 / 12 / 16 | |
| Bottom padding on sticky-bar screens | 110–130px | n/a |

## 8. Radius

| Role | Value |
|---|---|
| Controls (buttons, inputs, textareas) | 10px |
| Cards, media wells, code blocks | 14px |
| Chips, dots, avatars, badges | 9999px |

Replaces the mixed 8 / 12 / 16 / 24 (`rounded-lg`, `!rounded-xl`, `rounded-2xl`) in the current mobile scroll. One radius per role.

## 9. Targets

| Role | Value |
|---|---|
| Absolute minimum | 44px (unchanged from `index.css`) |
| Primary button | 52px (50px inside the sticky bar) |
| Input / textarea row | 52px |
| Menu row | 56px |
| List row | 60–64px |
| Nav bar | 56px |
| Sticky action bar | 84px incl. safe area |

## 10. Motion

| Property | Value |
|---|---|
| Duration | 200–250ms |
| Easing | `ease-out` |
| Animated properties | `color`, `background-color`, `border-color`, `opacity`, `transform: translate` only |

Dropped below `md`: `hover:scale-105`, `hover:scale-[1.02]`, `hover:shadow-xl hover:shadow-cyan-500/50`, `animate-glow-pulse`, `animate-gradient-shift`, `.aurora-shimmer`, `.ambient-orb`, `.animate-hyperdimensional-float`, `.animate-w-drift`, `.animate-tesseract-project`, and the `VoronoiGoldenHero` canvas. Keep the existing `prefers-reduced-motion` block.

---

## 11. Diff against the codebase

### `src/index.css`

Add inside the existing `@layer base` — mobile-only, so desktop is untouched:

```css
@layer base {
  @media (max-width: 767px) {
    :root {
      --background: 240 10% 6%;      /* #0E0E11 — hero anthracite */
      --radius: 0.625rem;            /* 10px controls */
    }
    body { font-size: 1.0625rem; line-height: 1.65; }  /* 17px reading default */
    input, textarea, select { font-size: 16px; }        /* stop iOS focus zoom */
  }
}
```

The last rule is the single highest-value line in this document: `src/components/ui/input.tsx` renders `text-sm` (14px), which makes iOS zoom the viewport every time a user taps a field on `/contact`.

### `src/styles/design-tokens.css`

Append; do not modify the existing blocks:

```css
:root {
  --dl-m-base:        #0E0E11;
  --dl-m-sunken:      #0B0B0E;
  --dl-m-raised:      #17171C;
  --dl-m-hairline:    rgba(255,255,255,.08);
  --dl-m-hairline-2:  rgba(255,255,255,.12);
  --dl-m-field:       rgba(255,255,255,.03);
  --dl-m-fg:          #FAFAFA;
  --dl-m-body:        rgba(250,250,250,.62);
  --dl-m-muted:       rgba(250,250,250,.45);
  --dl-m-faint:       rgba(250,250,250,.35);
  --dl-m-action:      #06B6D4;
  --dl-m-action-ink:  #04202A;
  --dl-m-action-br:   #22D3EE;
  --dl-m-action-tint: rgba(34,211,238,.12);
}

@media (max-width: 767px) {
  .glass-card,
  .glass-card-interactive {
    background: transparent;
    backdrop-filter: none;
    -webkit-backdrop-filter: none;
    border: 0;
    border-top: 1px solid var(--dl-m-hairline);
    border-radius: 0;
  }
  .glass-card-interactive:hover { transform: none; box-shadow: none; }
  .ambient-orb, .aurora-shimmer::after { display: none; }
}
```

That media block alone converts every outcome card and co-create card on mobile from a bordered glass box to a hairline-separated row — most of Rule 2, without touching a single `.tsx` file.

### `tailwind.config.ts`

```ts
extend: {
  colors: {
    dlm: {
      base:    '#0E0E11',
      sunken:  '#0B0B0E',
      raised:  '#17171C',
      action:  '#06B6D4',
      ink:     '#04202A',
      bright:  '#22D3EE',
    },
  },
  fontSize: {
    'm-h1':   ['2rem',     { lineHeight: '1.15', letterSpacing: '-0.02em', fontWeight: '600' }],
    'm-h1s':  ['1.875rem', { lineHeight: '1.18', letterSpacing: '-0.02em', fontWeight: '600' }],
    'm-h2':   ['1.375rem', { lineHeight: '1.3',  letterSpacing: '-0.01em', fontWeight: '600' }],
    'm-quote':['1.1875rem',{ lineHeight: '1.55' }],
    'm-title':['1.0625rem',{ lineHeight: '1.65', fontWeight: '600' }],
    'm-read': ['1.0625rem',{ lineHeight: '1.7' }],
    'm-body': ['1rem',     { lineHeight: '1.65' }],
    'm-sub':  ['0.875rem', { lineHeight: '1.55' }],
    'm-meta': ['0.6875rem',{ lineHeight: '1', letterSpacing: '0.16em', fontWeight: '500' }],
  },
  spacing: { 'safe-bar': '7.5rem' },  // 120px bottom clearance for the sticky bar
}
```

No new keyframes. Several existing ones (`glow-pulse`, `gradient-shift`, `hyperdimensional-*`, `w-drift`, `tesseract-project`, `dimensional-shimmer`, `node-breathe`, `connection-flow`) should simply not be applied below `md`.

### What NOT to change

- `--primary` stays blue-500. It is the shadcn focus ring and desktop primary; the mobile action colour is separate and explicit.
- The `min-height: 44px` base rule stays exactly as is.
- The `prefers-reduced-motion` and `@media print` blocks stay as is.
- `--dl-accent-*` values stay as is — they remain correct for desktop and for data.
