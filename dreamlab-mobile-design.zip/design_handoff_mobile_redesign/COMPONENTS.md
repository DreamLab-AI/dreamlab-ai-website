# Components

Twelve components carry all ten screens. Each entry gives anatomy, exact values, states, and the repo file it replaces. Class names refer to `mobile-tokens.css`; implement as Tailwind utilities if you prefer — the values are what matter.

---

## 1. Nav bar

**Replaces** `src/components/Header.tsx` below `md`.

- Sticky, `top: 0`, `z-index: 50`, height **56px** (currently 81px on mobile).
- Background `rgba(14,14,17,.92)` + `backdrop-filter: blur(14px)`; bottom border `1px solid rgba(255,255,255,.08)`.
- Padding `0 24px`.

**Root state** — wordmark left, menu button right.
- Wordmark: 9px cyan dot (`#22D3EE`) + `DREAMLAB`, 14px / 600 / `letter-spacing: .14em`, `#FAFAFA`. Links to `/`.
- Menu button: 44×44, two 20×1.5px bars in `#FAFAFA`, `gap: 5px`, right-aligned. `aria-label="Open menu"`, `aria-expanded`.

**Pushed state** — back + title.
- Back chevron `‹` in a 44×44 tap area, then page title at 15px / 500 / `#FAFAFA`. Padding `0 16px 0 8px`.

**Notes.** The shipped header puts the dropdown trigger — a gradient dot, the word `MENU`, and a chevron — where the logo belongs, then sets a second `Partner With Us` CTA beside it, filling the bar with two competing controls and no brand. Drop the scroll-threshold background swap: at 92% opacity plus blur it reads correctly over both photo and flat backgrounds, so the `hasScrolled` state and its `shadow-purple-500/10` border are unnecessary on mobile. Keep the existing `--header-height` ResizeObserver publish; sticky sub-headers depend on it.

---

## 2. Menu overlay

**Replaces** the `DropdownMenu` in `Header.tsx` below `md`.

- Full-screen, opaque `#0E0E11`, own nav bar with a 44×44 `×` close.
- Two labelled groups, `THE LAB` and `THE PEOPLE`, using `.m-meta` at 11px mono / `.16em` / `rgba(250,250,250,.4)`, 24px above / 8px below.
- Rows: **56px** min height, 19px `#FAFAFA`, hairline between, optional right-hand count at 13px `rgba(250,250,250,.4)`.
- Order: Programmes (38 ideas) · Co-create (3 routes) · Research · Software ecosystem · Self-guided workshops (15 free) — then Team (44+) · Impact stories · Community forum (`SIGN IN`, cyan mono).
- Footer block: primary button `Schedule a lab visit`, then a centred 20px-gap row of Contact · LinkedIn · Bluesky · Privacy at 14px `rgba(250,250,250,.5)`.

**Notes.** Flat — the shipped `DropdownMenuSub` for "Lab" is a hover interaction inside a tap-only context, and it hides five of the site's nine destinations behind a second step. Trap focus while open, close on Escape and on route change, and set `overflow: hidden` on `body`.

---

## 3. List row (compact)

**Replaces** the outcome-card grid in `src/pages/Index.tsx`.

- `min-height: 60px`, padding `14px 0`, `border-top: 1px solid rgba(255,255,255,.08)`.
- Layout: flex, `gap: 14px` — 6px cyan dot · title (flex 1, 16px `#FAFAFA`) · count (13px `rgba(250,250,250,.45)`) · chevron `›` (15px `rgba(250,250,250,.35)`).
- Whole row is the link target.

**Notes.** One outcome card in the shipped build is a 40px icon tile, a count, a 16px title, a three-line description and an "Explore →" link inside a coloured border — roughly 190px tall. Eight of them is 1,500px of scroll. As rows: 480px, and scannable.

## 4. List row (detail)

Used on Programmes, Track detail and Impact stories where a description earns its place.

- `display: block`, padding `18px 0`, hairline top.
- Title 17px / 600 `#FAFAFA` (18px on Programmes, with the count right-aligned on the same baseline).
- Description 14px / 1.55 `rgba(250,250,250,.55)`, 4–5px below.
- Meta 11px mono `.12em` `rgba(250,250,250,.4)`, 8px below — e.g. `2 DAYS · RESIDENTIAL`.

---

## 5. Buttons

Three levels only.

| Level | Spec |
|---|---|
| Primary | 52px (50px in the bar), radius 10px, fill `#06B6D4`, label `#04202A` 16px/600, `:active` fill `#0891B2` |
| Outline | Same box, transparent fill, `1px solid rgba(255,255,255,.16)`, label `#FAFAFA` 16px/400, `:active` `rgba(255,255,255,.05)` |
| Text link | `min-height: 44px`, 15px `#22D3EE`, trailing `→` where it moves you forward |

**Notes.** No gradient fills, no `hover:scale`, no coloured glow shadows. `src/components/ui/button.tsx` stays as it is for desktop; mobile CTAs should either take the mobile classes or use `variant="default"` with a mobile-scoped override. One primary per screen — the shipped home page has five.

## 6. Chips

- `min-height: 40px`, padding `9px 14px`, radius 9999px, 14px text.
- Off: `1px solid rgba(255,255,255,.12)`, `rgba(250,250,250,.7)`.
- On: `1px solid #22D3EE`, fill `rgba(34,211,238,.12)`, text `#FAFAFA`.
- Implement as `<button aria-pressed>`; transition border and background only, 220ms.

Two uses: read-only facts (lab capability list on Home) and selection (engagement type on Enquire). Never navigation.

---

## 7. Stat quad

**Replaces** the evidence strip in `Index.tsx`.

- `grid-template-columns: 1fr 1fr`; each cell padding `22px 24px`.
- Hairline right on odd cells, hairline bottom on all but the last row.
- Figure 24px / 600 `#FAFAFA`; label 13px `rgba(250,250,250,.5)`, 2px below, lowercase.
- Content: `£8M+` research heritage · `30 yrs` deep tech R&D · `44+` specialists · `6.3kW` solar powered.

**Notes.** The shipped strip is a `flex-wrap` of four items with gradient-clipped text; at 390px it breaks 2 + 2 with uneven gutters, and `Lake District` — a phrase, not a figure — sits in the number slot. Swapped for `6.3kW`, which is a number and comes from the same facility list.

## 8. Form field

**Replaces** `src/components/ui/input.tsx` usage below `md`.

- Height 52px, radius 10px, `1px solid rgba(255,255,255,.14)`, fill `rgba(255,255,255,.03)`, text `#FAFAFA` **16px**.
- Label above: 14px `rgba(250,250,250,.75)`, 8px gap. Optional marker as a `rgba(250,250,250,.4)` suffix in the label, never a placeholder.
- Focus: border `#22D3EE`. No ring, no shadow.
- Textarea: same, `padding: 14px`, `line-height: 1.5`, `resize: none`, 4 rows.
- Consent row: 22px checkbox, `gap: 12px`, copy 14px / 1.5 `rgba(250,250,250,.65)`, whole row ≥44px.

**Notes.** 16px is a hard floor — `input.tsx` currently renders `text-sm` (14px), which makes iOS zoom the viewport on every field tap. The shipped consent copy is 12px at `text-muted-foreground/80`; that's the smallest legally meaningful text on the site and it's the least legible.

---

## 9. Sticky action bar

- Fixed bottom, `z-index: 40`, height **84px** including `env(safe-area-inset-bottom)`.
- Padding `12px 24px calc(20px + safe-area)`.
- Background `linear-gradient(to top, #0B0B0E 60%, rgba(11,11,14,0))` — a fade, not a hard edge.
- Contents: one 50px primary filling the width, optionally plus a 50×50 outline icon button.
- Every screen using it carries **120px** bottom padding on its scroll container.

Used on: Home, Track detail, Workshop module, Team. Not on Menu, Programmes, Workshops, Co-create, Stories, Enquire — those either end in their own CTA or *are* the action.

## 10. Progress

- **Header bar** (Workshop module): 2px, full-bleed under the nav, `rgba(255,255,255,.08)` track, `#22D3EE` fill.
- **Summary bar** (Workshops index): 4px, radius 9999px, same colours, with a label row above — `Your progress` 13px `rgba(250,250,250,.55)` left, `3 / 15` 11px mono `#FAFAFA` right.
- **Row state**: `DONE` 11px mono `rgba(250,250,250,.35)`; `RESUME` 11px mono `#22D3EE` on the first incomplete module only.

**Notes.** Replaces the per-card percentage bar and gradient CTA block in `src/components/WorkshopCard.tsx`. Percentages per module were precision no one asked for; done/not-done plus a single overall count is what a learner needs. Data source is unchanged (`useWorkshopProgress`).

## 11. Selectable card

Used only on Team.

- Two-column grid, `gap: 12px`, radius 14px, `overflow: hidden`.
- Photo area 120px, `object-fit: cover`. Body padding `12px 12px 14px`: name 15px / 600 `#FAFAFA`, role 13px `rgba(250,250,250,.5)`.
- Off: `1px solid rgba(255,255,255,.1)`, fill `rgba(255,255,255,.03)`.
- On: `2px solid #22D3EE` plus a 24px cyan circle top-right (10px inset) with `#04202A` check.
- `<button aria-pressed>`; announce as "Select <name>".

**Notes.** This is the one place a card is right — each tile is a real, individually selectable object. Selection state must be visible without colour alone; the check badge is the redundant cue.

## 12. Photo slot

- Full-bleed to the screen edge, height 200px (150px inside a bordered block), `object-fit: cover`.
- No radius at the screen edge, no shadow, no overlay gradient.
- Striped grey blocks in the mocks mark these; real sources are `/images/venue/*.webp` and `/images/team/*.webp`.

**Notes.** One static image, not the 4-second auto-rotating carousel currently on `/`. The carousel preloads seven `.webp` files and animates opacity indefinitely — cost with no interaction affordance, on the connection most likely to be metered.
