# Implementation

Suggested route through the work, file by file. Nothing here requires a new dependency, a new route, or a data-model change.

The whole redesign is **mobile-only**: every change is scoped under `max-width: 767px` (Tailwind's `md` breakpoint minus 1px, matching `src/hooks/use-mobile.tsx`, which uses `MOBILE_BREAKPOINT = 768`). Desktop rendering must be byte-identical when you're done.

---

## Order of work

### Step 1 — Tokens (half a day, no visual risk)

1. Append the token block from `TOKENS.md` §11 to `src/styles/design-tokens.css`, or import `mobile-tokens.css` after it.
2. Add the mobile `@layer base` block to `src/index.css`.
3. Add the `dlm` colours, `m-*` font sizes and `safe-bar` spacing to `tailwind.config.ts`.

**Ship this on its own.** The `input, textarea, select { font-size: 16px }` rule alone fixes the iOS focus-zoom on every form in the site, and the `.glass-card` mobile override converts every outcome and co-create card to a hairline row without touching a `.tsx` file. Two rules, most of the clutter complaint.

### Step 2 — Header + menu (`src/components/Header.tsx`)

The highest-value component change. Currently one component serves both breakpoints and neither well.

- Below `md`: 56px bar, wordmark left → `/`, hamburger right.
- Replace the `DropdownMenu` with a full-screen overlay (`src/components/ui/sheet.tsx` is already a dependency and does focus trap + Escape + body lock — use it rather than hand-rolling).
- Flatten the menu: no `DropdownMenuSub`. Groups are visual headings only.
- Drop the `Partner With Us` CTA from the mobile bar; it moves to the sticky action bar and the menu footer.
- Keep the `--header-height` ResizeObserver publish — `WorkshopHeader` and other sticky sub-headers offset by it.
- Keep the desktop branch exactly as it is.

### Step 3 — Sticky action bar (new, ~40 lines)

`src/components/MobileActionBar.tsx` — `{ label, href, secondaryHref? }`, rendered only below `md`. Values in `COMPONENTS.md` §9. Pages using it add `pb-safe-bar`.

### Step 4 — Home (`src/pages/Index.tsx`)

The biggest file change. Nine sections become six.

- Gate the hero background: `const isMobile = useIsMobile()` (the hook exists) and skip the `<Suspense><HyperdimensionalHeroBackground/></Suspense>` mount entirely below `md` — not `hidden md:block`, which still downloads and runs the canvas chunk.
- Replace the hero block with eyebrow / 32px H1 / 17px body / one primary / one text link. Drop the scroll chevron.
- Facility section: one static `<img>` (`/images/venue/aerial.webp`) instead of the seven-image `setInterval` carousel below `md`; the 2×2 feature boxes become the chip row in "The lab".
- Evidence strip → stat quad, with `6.3kW` replacing `Lake District`.
- `outcomeCards.map` → compact rows. Keep the array, keep the icons for desktop, drop `borderClass` / `iconBg` on mobile.
- Co-create cards → three detail rows.
- Remove below `md`: team preview section, dual CTA blocks, email signup section.
- Footer: single column, links in a wrapped row, 130px bottom padding.

Do this as a `useIsMobile()` branch or as parallel section components — whichever keeps the desktop tree provably untouched. A large `Index.tsx` split into `<HeroMobile/>` / `<HeroDesktop/>` etc. is easier to review than 40 interleaved `md:` overrides.

### Step 5 — Programmes + track detail (`src/pages/Programmes.tsx`)

Rows and a per-track view. If tracks are currently anchor sections on one long page, mobile should route to a real detail view — a 36KB single page is a poor phone experience and the back-button behaviour is better.

### Step 6 — Workshops (`src/pages/WorkshopIndex.tsx`, `WorkshopPage.tsx`, `WorkshopCard.tsx`)

- Index: rows, not cards. `WorkshopCard` is ~200 lines producing a 14px module badge, a rotating icon tile, three tag pills, a percentage bar and a gradient CTA block per module — none of it survives at 390px. Render the row form below `md`.
- Fix the display names (`SCREENS.md` §05) — ideally in `scripts/generate-workshop-list.mjs` so both breakpoints benefit.
- Module page: 17/1.7 prose, 2px header progress bar, sticky `Mark done · next step`.

### Step 7 — Team, Stories, Co-create, Enquire

- `Team.tsx`: two-column selectable grid; move the counter into the sticky bar. Selection logic unchanged.
- `Testimonials.tsx`: quote-led blocks from `testimonials.json`.
- `CoCreate.tsx`: three hairline blocks.
- `Contact.tsx` + `EmailSignupForm.tsx`: merge into one enquiry form. Keep the NIP-17 submission path exactly as it is; only presentation changes. Add the engagement chips and the encryption line.

---

## What NOT to touch

- **Any `md:` and above rendering.** The desktop site is signed off as is.
- **`--primary`** (`hsl(217 91% 60%)`). It is the shadcn focus ring and desktop primary. The mobile action colour is separate and explicit.
- **The `min-height: 44px` base rule** in `index.css`.
- **`prefers-reduced-motion` and `@media print` blocks.**
- **`--dl-accent-*`** in `design-tokens.css` — still correct for desktop and for data.
- **The NIP-17 signup/enquiry submission path** in `EmailSignupForm.tsx` and `src/lib/nostr.ts`. Presentation only.
- **`useWorkshopProgress`** storage shape.
- **`src/components/ui/*`** primitives, except where a mobile-scoped class overrides presentation. Don't fork shadcn components.

---

## Risks and watch-outs

| Risk | Mitigation |
|---|---|
| `md:` regressions from shared components | Snapshot desktop before/after at 1440px for `/`, `/programmes`, `/workshops`, `/team`, `/contact`. The existing Playwright setup (`npm run test:e2e`) can carry these. |
| Lazy chunks still loading on mobile | Gate the *mount*, not the visibility. `hidden md:block` still executes `VoronoiGoldenHero`'s canvas loop. |
| `--header-height` consumers breaking at 56px | Value is published by ResizeObserver, so it follows automatically — but check `WorkshopHeader`'s sticky offset visually. |
| Sticky bar covering content | Every scroll container on a bar screen needs `pb-safe-bar` (120px). Easy to forget on newly added sections. |
| Safe-area on notched devices | `env(safe-area-inset-bottom)` is in the bar padding; confirm `viewport-fit=cover` is set in `index.html`. |
| Focus trap in the menu overlay | Use the existing `sheet.tsx` / Radix Dialog rather than a hand-rolled overlay. |
| iOS zoom returning | Any new `text-sm` input reintroduces it. Consider an ESLint rule or a review note. |

---

## Definition of done

- [ ] Desktop screenshots at 1440px identical before/after on all ten routes.
- [ ] At 390px: no horizontal scroll on any route.
- [ ] Every interactive target ≥44px; primaries ≥50px.
- [ ] No input below 16px; tapping any field on iOS Safari does not zoom.
- [ ] One solid-cyan primary visible per screen.
- [ ] No canvas, orb, shimmer or float animation mounts below `md` (verify in the Performance panel, not by eye).
- [ ] `prefers-reduced-motion: reduce` removes all remaining transitions.
- [ ] Menu: focus trapped, Escape closes, body scroll locked, `aria-expanded` correct.
- [ ] Team selection state announced by a screen reader without relying on colour.
- [ ] Lighthouse mobile performance and accessibility measured before and after on `/`.
