# Handoff: DreamLab AI mobile web redesign

## Overview

The DreamLab AI marketing site (`DreamLab-AI/dreamlab-ai-website`, branch `main`) renders its desktop layout down to 390px without a mobile-specific design. The result is hard to read and cluttered: a full-viewport animated Voronoi hero carrying a 24px wordmark, `MENU` where the logo belongs, eight glass cards in eight border hues down one scroll, gradient-clipped stat text that wraps into a ragged pile, nine sections and five competing CTAs, and 14px form inputs that make iOS zoom on focus.

This package redesigns the **mobile web experience only**. The desktop site is unchanged — nothing in here should alter rendering at `md:` and above. Every token is inherited from the shipped codebase; no new brand was invented.

Scope: ten screens plus a mobile design system.

## About the design files

The `.dc.html` files bundled here are **design references written in HTML** — prototypes that show intended look, spacing and behaviour. They are not production code and should not be copied into the app.

The task is to **recreate these designs in the existing codebase**: React 18.3 + TypeScript + Vite, Tailwind 3.4, shadcn/ui, `react-router-dom`, `lucide-react` icons. Use the established patterns already in `src/` — Tailwind utility classes, the `cn()` helper, the shadcn primitives in `src/components/ui/`, route components in `src/pages/`. Where these mocks use inline styles, that is an artefact of the prototyping environment; the implementation should use Tailwind classes and the token additions described in `TOKENS.md`.

Icon placeholders in the mocks are drawn as plain coloured squares. **Do not implement them as squares** — use the existing `lucide-react` icons already imported in `src/pages/Index.tsx` (`Rocket`, `Brain`, `Globe`, `Glasses`, `ShieldCheck`, `Bot`, `Fingerprint`, `Palette`, `Building2`, `Beaker`, `GraduationCap`, `Handshake`, `Users`, `ArrowRight`, `ChevronDown`). Striped grey blocks mark photo slots; the real images already exist under `/images/venue/` and `/images/team/`.

## Fidelity

**High fidelity.** Colours, type scale, spacing, radii and touch targets are final and exact — implement them as specified. Copy is final except where a file notes it as illustrative (the six course ideas on the track-detail screen are written for the mock; real course data should come from the programmes source).

Interaction detail (transitions, sticky behaviour, selection states) is specified in `SCREENS.md` and `COMPONENTS.md`.

## Bundle contents

| File | What it is |
|---|---|
| `README.md` | This file — start here |
| `TOKENS.md` | Every design value, with the exact diff against `index.css`, `design-tokens.css` and `tailwind.config.ts` |
| `mobile-tokens.css` | Paste-ready CSS custom properties and utility classes |
| `COMPONENTS.md` | Each component: anatomy, exact values, states, and which repo file it replaces |
| `SCREENS.md` | Each of the ten screens: layout, content, behaviour, state |
| `IMPLEMENTATION.md` | Suggested order of work, file-by-file changes, risks, and what NOT to touch |
| `DreamLab Mobile Site.dc.html` | The ten screens, live |
| `DreamLab Mobile Design System.dc.html` | Tokens and component specimens, live |
| `DreamLab Mobile.dc.html` | Direction comparison, including a pixel recreation of the current mobile home |

Open the `.dc.html` files in a browser. The design-system file documents the same values as `TOKENS.md` visually.

## The five rules

Everything else follows from these. If a decision isn't covered by this bundle, decide with these.

1. **One accent per screen.** Cyan means "you can act here". The eight track hues and the Voronoi gold/bronze stay on desktop and in data keys — never as eight card borders in one mobile scroll.
2. **Rules, not walls.** At 390px a bordered card is a box inside a box. Separate list items with a 1px hairline; reserve cards for things that are genuinely objects (a selectable person, a media well).
3. **One primary action per screen.** Everything else is a text link. The primary lives in a sticky bottom bar so it survives a long scroll.
4. **Headline beats hero.** Mobile opens with a 32px sentence that states the offer, not a full-viewport canvas.
5. **Say it once.** Repeated reassurance ("every course is shaped around your team") appears once per screen. Cutting repetition removed roughly a third of the home page's height.

## Screens

Full detail in `SCREENS.md`.

| # | Screen | Route | Replaces |
|---|---|---|---|
| 01 | Home | `/` | `src/pages/Index.tsx` mobile rendering |
| 02 | Menu | overlay | `src/components/Header.tsx` dropdown |
| 03 | Programmes | `/programmes` | outcome-card grid |
| 04 | Track detail | `/programmes#<id>` | anchor sections |
| 05 | Workshops | `/workshops` | `src/pages/WorkshopIndex.tsx` |
| 06 | Workshop module | `/workshops/:id/:slug` | `src/pages/WorkshopPage.tsx` |
| 07 | Co-create | `/co-create` | `src/pages/CoCreate.tsx` |
| 08 | Team | `/team` | `src/pages/Team.tsx` |
| 09 | Impact stories | `/testimonials` | `src/pages/Testimonials.tsx` |
| 10 | Enquire | `/contact` | `EmailSignupForm` + contact form |

## Interactions & behaviour

Summary; per-screen detail in `SCREENS.md`.

- **Navigation.** Menu is a full-screen overlay (not a dropdown), flat — no submenus. Push navigation swaps the nav bar to back-arrow + page title.
- **Sticky action bar.** Fixed to the bottom on Home, Track detail, Workshop module and Team. 84px including safe area, with a gradient fade so content doesn't hard-cut. Every scrolling screen carries 110–130px of bottom padding to clear it.
- **Transitions.** 200–250ms, `ease-out`, colour and opacity only. No hover-scale, no glow shadows, no gradient animation on mobile — a touch device has no hover, and the shipped `hover:scale-105` / `hover:shadow-cyan-500/50` patterns produce nothing but paint cost.
- **Reduced motion.** Honour `prefers-reduced-motion` as `src/index.css` already does. The Voronoi canvas, ambient orbs, aurora shimmer and hyperdimensional float should not mount below `md`.
- **Selection (Team).** Tap toggles selection: 2px cyan border plus a 24px cyan check badge top-right. The sticky bar shows "N specialists selected" and enquiring carries the names to `/contact`, matching the existing `handleEnquire` in `src/pages/Team.tsx`.
- **Progress (Workshops).** Reuse `src/hooks/useWorkshopProgress.ts`. Completed modules show a muted `DONE` in mono; the first incomplete module shows `RESUME` in cyan. A 4px bar at the top of the list shows `n / 15`.
- **Forms.** Inputs are 52px tall with 16px text — below 16px iOS zooms the page on focus, which the current 14px inputs do. Labels above the field, never placeholder-as-label. Focus is a cyan border, no ring glow. Validation and submission behaviour are unchanged from `EmailSignupForm.tsx` (NIP-17 gift-wrapped DM; success only on relay OK-true).

## State management

No new global state. Per-screen:

| Screen | State | Source |
|---|---|---|
| Menu | `isOpen: boolean` | local to header |
| Workshops | per-module progress | existing `useWorkshopProgress` |
| Workshop module | current step index | existing page state |
| Team | `selectedMembers: string[]` | existing `Team.tsx` state, unchanged |
| Enquire | form fields, consent, `isSubmitting` | existing `EmailSignupForm` state |

## Assets

Nothing new is required.

- **Photography** — existing `/images/venue/*.webp` (`aerial`, `fairfield-front`, `fairfield-back`, `view`, `labview2`, `labview3`, `remarkable2`) and `/images/team/*.webp`. Striped blocks in the mocks mark the slots.
- **Icons** — existing `lucide-react`.
- **Fonts** — unchanged. The Tailwind default system sans stack, plus `ui-monospace, Menlo, monospace` for meta labels (already available, no webfont needed).

The auto-rotating facility carousel on `/` (4s interval) is dropped on mobile in favour of one static image — see `IMPLEMENTATION.md`.

## Source of truth

Values in this bundle were read from, and should stay consistent with:

`src/index.css` · `src/styles/design-tokens.css` · `tailwind.config.ts` · `src/pages/Index.tsx` · `src/components/Header.tsx` · `src/components/EmailSignupForm.tsx` · `src/components/HyperdimensionalHeroBackground.tsx` · `src/components/WorkshopCard.tsx` · `src/pages/Team.tsx` · `src/data/workshop-list.json` · `src/data/testimonials.json` · `src/components/ui/button.tsx` · `src/components/ui/card.tsx`

The project root `github.md` maps each design screen to the repo files it was built from.
